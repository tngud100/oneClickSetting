'use strict';

chrome.runtime.onInstalled.addListener(function() {
	/**
	 * lets add a default domain
	 * for our options page
	*/
	chrome.storage.local.get(null, function(result) {
		var Scripts = result,
				Count = 0;

		for(var key in Scripts){
			if(key != 'config'){
				Count++;
			}
		}

		if(Count == 0){			
			chrome.storage.local.set(
				{
					FirstScript: {
						Domain: "",
						Type: "JS",
						ExecType: 0,
						Content: "console.log('First Script');",
						Status: "Active"
					},
					FirstStyle: {
						Domain: "",
						Type: "CSS",
						ExecType: 0,
						Content: ".Test { background-color: black; }",
						Status: "Active"
					},
					DarkModeExtreme: {
						Domain: "",
						Type: "JS",
						ExecType: 1,
						Content: "if(document.querySelectorAll('#DMExtreamStyle').length == 0){var scriptElm = document.createElement('style');scriptElm.id = 'DMExtreamStyle';scriptElm.innerHTML = 'body.DMExtreamStyle,body.DMExtreamStyle a,body.DMExtreamStyle abbr,body.DMExtreamStyle acronym,body.DMExtreamStyle address,body.DMExtreamStyle applet,body.DMExtreamStyle area,body.DMExtreamStyle article,body.DMExtreamStyle aside,body.DMExtreamStyle b,body.DMExtreamStyle base,body.DMExtreamStyle basefont,body.DMExtreamStyle bdi,body.DMExtreamStyle bdo,body.DMExtreamStyle big,body.DMExtreamStyle blockquote,body.DMExtreamStyle br,body.DMExtreamStyle button,body.DMExtreamStyle canvas,body.DMExtreamStyle caption,body.DMExtreamStyle center,body.DMExtreamStyle cite,body.DMExtreamStyle code,body.DMExtreamStyle col,body.DMExtreamStyle colgroup,body.DMExtreamStyle data,body.DMExtreamStyle datalist,body.DMExtreamStyle dd,body.DMExtreamStyle del,body.DMExtreamStyle details,body.DMExtreamStyle dfn,body.DMExtreamStyle dialog,body.DMExtreamStyle dir,body.DMExtreamStyle div,body.DMExtreamStyle dl,body.DMExtreamStyle dt,body.DMExtreamStyle em,body.DMExtreamStyle embed,body.DMExtreamStyle fieldset,body.DMExtreamStyle figcaption,body.DMExtreamStyle figure,body.DMExtreamStyle font,body.DMExtreamStyle footer,body.DMExtreamStyle form,body.DMExtreamStyle frame,body.DMExtreamStyle frameset,body.DMExtreamStyle h1,body.DMExtreamStyle h2,body.DMExtreamStyle h3,body.DMExtreamStyle h4,body.DMExtreamStyle h5,body.DMExtreamStyle h6,body.DMExtreamStyle head,body.DMExtreamStyle header,body.DMExtreamStyle hr,body.DMExtreamStyle html,body.DMExtreamStyle iframe,body.DMExtreamStyle input,body.DMExtreamStyle ins,body.DMExtreamStyle kbd,body.DMExtreamStyle label,body.DMExtreamStyle legend,body.DMExtreamStyle li,body.DMExtreamStyle link,body.DMExtreamStyle main,body.DMExtreamStyle map,body.DMExtreamStyle mark,body.DMExtreamStyle meta,body.DMExtreamStyle meter,body.DMExtreamStyle nav,body.DMExtreamStyle noframes,body.DMExtreamStyle noscript,body.DMExtreamStyle object,body.DMExtreamStyle ol,body.DMExtreamStyle optgroup,body.DMExtreamStyle option,body.DMExtreamStyle output,body.DMExtreamStyle p,body.DMExtreamStyle param,body.DMExtreamStyle pre,body.DMExtreamStyle progress,body.DMExtreamStyle q,body.DMExtreamStyle rp,body.DMExtreamStyle rt,body.DMExtreamStyle ruby,body.DMExtreamStyle s,body.DMExtreamStyle samp,body.DMExtreamStyle script,body.DMExtreamStyle section,body.DMExtreamStyle select,body.DMExtreamStyle small,body.DMExtreamStyle source,body.DMExtreamStyle span,body.DMExtreamStyle strike,body.DMExtreamStyle strong,body.DMExtreamStyle style,body.DMExtreamStyle sub,body.DMExtreamStyle summary,body.DMExtreamStyle sup,body.DMExtreamStyle table,body.DMExtreamStyle tbody,body.DMExtreamStyle td,body.DMExtreamStyle template,body.DMExtreamStyle textarea,body.DMExtreamStyle tfoot,body.DMExtreamStyle th,body.DMExtreamStyle thead,body.DMExtreamStyle time,body.DMExtreamStyle title,body.DMExtreamStyle tr,body.DMExtreamStyle track,body.DMExtreamStyle tt,body.DMExtreamStyle u,body.DMExtreamStyle ul,body.DMExtreamStyle var,body.DMExtreamStyle wbr{background-color:#2d2d2d !important; color: #e7e8eb !important;}body.DMExtreamStyle video,body.DMExtreamStyle picture,body.DMExtreamStyle img{z-index:1000000000;}body.DMExtreamStyle svg,body.DMExtreamStyle i{color:#e7e8eb; fill:#e7e8eb;}';document.body.appendChild(scriptElm);}var body = document.querySelectorAll('body');body[0].classList.toggle('DMExtreamStyle');",
						Status: "Active"
					}
				},
				function() {
			    console.log('Settings saved');
			  }
			);
		}
	});
});
