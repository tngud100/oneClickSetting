// Inicializar general
function InputTypeCheck(selector = "") {
  selector = (selector != "") ? selector + " " : selector;

  // Formato de los inputs según clases
	$(selector+'.input-number').on('input', function () { 
	  this.value = this.value.replace(/[^0-9]/g,'');
	});
  $(selector+'.input-alphanumber').on('input', function () { 
    this.value = this.value.replace(/[^a-zA-Z0-9]/g,'');
  });
  $(selector+'.input-numberspercent').on('input', function () { 
    this.value = this.value.replace(/[^0-9\%]/g,''); 
  });
  $(selector+'.input-numberphone').on('input', function () { 
    this.value = this.value.replace(/[^0-9\-+]/g,''); 
  });
	$(selector+'.input-numberdecimal').on('input', function () { 
	  this.value = this.value.match(/^\d+\.?\d{0,2}/); 
	});
  $(selector+'.input-numberthousandseparator').on('input', function () { 
    this.value = this.value.replace(/[^0-9]/g, '').replace(/\B(?=(\d{3})+(?!\d)\.?)/g, '.'); 
  });
  $(selector+'.input-numbereuroformat').blur( function () {
    $(this).val(NumberFormat($(this).val(), 2, ',', '.') + ' €'); 
  });
	$(selector+'.input-nonspaces').on('input', function () { 
	  this.value = this.value.replace(/\s/g, '');
	});
  $(selector+'.input-maxlength').on('input', function () { 
    var id = $(this).attr('id'),
        maxlength = $(this).attr('maxlength'),
        remaining = maxlength - $(this).val().length;
    $('#SpanAppend'+id).html(remaining);
  });

  // Quita clase error al cambiar un input o select
	$(selector+'input').on('input', function () { 
	  $(this).removeClass('FieldError');
	});
	$(selector+'input, '+selector+'select').on('change', function () { 
    if($(this).hasClass('jqmsLoaded')){
      $(this).siblings('.ms-options-wrap').find('button').removeClass("FieldError");
    } else {
      $(this).removeClass('FieldError');
    }
	});

  var cmArray = document.querySelectorAll('.CodeMirrorClass');
  for (var i = 0; i < cmArray.length; i++) {    
    var cm = CodeMirror(cmArray[i], {
          lineNumbers: true,
          indentUnit: 2,
          smartIndent: true,
          tabSize: 2,
          indentWithTabs: true,
          lineWrapping: true,
          readOnly: false,
          mode: 'javascript',
          theme: 'monokai-abc',
          value: ''
        }),
        changemode = cmArray[i].getAttribute('data-changemode') || '',
        id = cmArray[i].id;
    $('#'+id).data('CodeMirrorInstance', cm);
    if(changemode != ''){
      $(changemode).change(function () {
        var mode = $(this).val() || 'JS',
            mode = mode == 'JS' ? 'javascript' : (mode == 'CSS' ? 'css' : 'javascript');
        cm.setOption('mode', mode);
      });
    }
  }
}

InputTypeCheck();