// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

var Scripts;

$('#AddEditButton').click(AddEditConfig);
$('#CleanConfigButton').click(function () {	
	$('#AddingTitle').val('');
	$('#AddingDomain').val('');
	$('#AddingType').val('');
	$('#AddingType').trigger("change");
	$('#AddingExecType').prop('checked', false);
	$('#AddingExecType').trigger("change");
  var cm = $('#AddingContent').data('CodeMirrorInstance');
	cm.setValue('');
});
$('#AddingExecType').change(function () {
	if($(this).is(':checked')){
		$('#AddingExecTypeInfo').addClass('Show');
	} else {
		$('#AddingExecTypeInfo').removeClass('Show');
	}
});

chrome.storage.local.get(null, function(result) {
	Scripts = result;

	var ScriptsHTML = '';
	for(var key in Scripts){
		if(key != 'config'){
			if(Scripts[key].Status === undefined || Scripts[key].Status != 'Inactive'){		
				ScriptsHTML += ''+
					'<tr>'+
						'<td>'+
							'<i class="fas fa-pencil-alt EditButton" data-key="'+key+'"></i>'+
							'<i class="fas fa-trash-alt EraseButton" data-key="'+key+'"></i>'+
						'</td>'+
						'<td>'+key+'</td>'+
						'<td style="word-break: break-all;">'+Scripts[key].Domain+'</td>'+
					'</tr>';
			}
		}
	}

	$('#ConfiguredScripts tbody').html(ScriptsHTML);
	$('.EditButton').click(ShowConfig);
	$('.EraseButton').click(EraseConfig);
});

function ShowConfig() {
	var keyString = $(this).attr('data-key');
	for(var key in Scripts){
		if(key == keyString){
			var checked = Scripts[key].ExecType == 1 ? true : false;
			$('#AddingTitle').val(key);
			$('#AddingDomain').val(Scripts[key].Domain);
			$('#AddingType').val(Scripts[key].Type);
			$('#AddingType').trigger("change");
			$('#AddingExecType').prop('checked', checked);
			$('#AddingExecType').trigger("change");
		  var cm = $('#AddingContent').data('CodeMirrorInstance');
			cm.setValue(Scripts[key].Content);
		}
	}
	$('html, body').animate({ scrollTop: 0 }, 200);
}

function EraseConfig() {
	var keyString = $(this).attr('data-key'),
			ErasingItem = {};

	for(var key in Scripts){
		if(key == keyString){
			ErasingItem[key] = {
				Domain: Scripts[key].Domain,
				Type: Scripts[key].Type,
				ExecType: Scripts[key].ExecType,
				Content: Scripts[key].Content,
				Status: "Inactive"
			};
					
			chrome.storage.local.set(
				ErasingItem,
				function() {
			    console.log('Settings saved');
			  }
			);
		}
	}

	location.reload();
}

function AddEditConfig() {
	var AddingTitle = $('#AddingTitle').val(),
			AddingDomain = $('#AddingDomain').val(),
			AddingType = $('#AddingType').val(),
			AddingExecType = $('#AddingExecType').is(':checked') ? 1 : 0,
		  cm = $('#AddingContent').data('CodeMirrorInstance'),
			AddingContent = cm.getValue(),
			AddingContent = AddingContent.replace('"', '\"'),
			AddingItem = {};

	AddingItem[AddingTitle] = {
		Domain: AddingDomain,
		Type: AddingType,
		ExecType: AddingExecType,
		Content: AddingContent,
		Status: "Active"
	};
			
	chrome.storage.local.set(
		AddingItem,
		function() {
	    console.log('Settings saved');
	  }
	);

	location.reload();
}