'use strict';

var Scripts,
		fullPath;

$('#OptionsButton').click(OpenOptions);

var query = { active: true, currentWindow: true };
function GetTabData(tabs) {
  var currentTab = tabs[0]; // there will be only one in this array
  fullPath = currentTab.url;

	chrome.storage.local.get(null, function(result) {
		Scripts = result;

		var ScriptsHTML = '',
				Count = 0;
		for(var key in Scripts){
			if(key != 'config'){
				if((Scripts[key].Status === undefined || Scripts[key].Status != 'Inactive') && Scripts[key].ExecType == 1){
			    var domainArray = Scripts[key].Domain.split(',');
			    
					domainArray.map(function(s) { return s.trim(); });

			    var domainRegExp = domainArray.join('|'),
			    		regex = new RegExp('('+domainRegExp+')','gim');

			    if(regex.test(fullPath)){
						ScriptsHTML += ''+
							'<div class="script-item">'+
								'<button type="button" class="btn btn-primary form-control ManualExec" data-key="'+key+'">'+
									'<i class="fas fa-play"></i> '+key+
								'</button>'+
							'</div>';
						Count++;
					}
				}
			}
		}

		if(Count == 0){
			ScriptsHTML += ''+
				'<div class="script-item">'+
					'No items match this page.'+
				'</div>';
		}

		$('#ManualExecList').html(ScriptsHTML);
		$('.ManualExec').click(ExecConfig);
	});
}
chrome.tabs.query(query, GetTabData);

function OpenOptions() {
	chrome.runtime.openOptionsPage(null);
}

function ExecConfig() {
	var keyString = $(this).attr('data-key'),
			ItemString = '';

	if(Scripts[keyString].Type == 'JS'){
		var Query = Scripts[keyString].Content.replace(/\n/g, ""),
				Query = Query.replace(/\"/g, "\\\"");
		ItemString = ''+
			'var scriptElm = document.createElement(\'script\');'+
			'scriptElm.innerHTML = "'+Query+'";'+
			'document.body.appendChild(scriptElm);';
	} else if(Scripts[keyString].Type == 'CSS'){
		var Query = Scripts[keyString].Content.replace(/\n/g, ""),
				Query = Query.replace(/\"/g, "\\\"");
		ItemString = ''+
			'var scriptElm = document.createElement(\'style\');'+
			'scriptElm.innerHTML = "'+Query+'";'+
			'document.body.appendChild(scriptElm);';
	}

  chrome.tabs.query({ active: true, currentWindow: true}, function(activeTabs) {
    chrome.tabs.executeScript(activeTabs[0].id, { code: ItemString });
  });
}